//
// Created by Dayal Kumar on 02/11/23.
//

#ifndef DELHIMETRO_DELHIMETRO_H
#define DELHIMETRO_DELHIMETRO_H

namespace DelhiMetro {
	void render_app(bool* p_open);
}

#endif //DELHIMETRO_DELHIMETRO_H
